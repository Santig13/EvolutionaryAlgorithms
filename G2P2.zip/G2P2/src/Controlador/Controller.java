package Controlador;

import Presentacion.GUI;

public interface Controller {

	public void run(GUI gui,TParametros parametros);
}
