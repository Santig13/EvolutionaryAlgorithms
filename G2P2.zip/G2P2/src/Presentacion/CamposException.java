package Presentacion;

public class CamposException extends Exception {

	public CamposException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

}
