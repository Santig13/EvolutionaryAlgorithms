package Presentacion;
import Controlador.TResultStatistics;

public interface GUI {
	public void update(TResultStatistics Trs);
}
